# Asset Drawer
 Plugin for the Godot game engine that allows you to dock the file system to the bottom of the editor is where Output and your Debugging tools are located where windows can not normally be docked to. Click on the file split button(part of godot) to split it to a horizontal system. You can also use the shortcut ctrl + space to popup and hide the asset drawer at anytime.


**Dock to the Bottom**
<br><br>
<img src="hubimages/BottomDock.png" >
<br><br>
**Slide the split all the way to the left to remove the file tree, and bring it back anytime**
<br><br>
<img src="hubimages/BottomDock2.png" >
<br><br>
